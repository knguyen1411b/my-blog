# Portfolio content rewrite — 2026-10-15

Mục tiêu: thương hiệu cá nhân và tuyển dụng Fullstack. Case study viết bằng tiếng Anh; hai bài blog liên quan viết bằng tiếng Việt. Giữ nguyên 11 project ID và các URL đã có.

## Nội dung

- `source/projects.json`: bản sao dữ liệu công khai từ Firestore trước khi chỉnh nội dung.
- `source/repos/`: README, manifest và một số file nguồn công khai dùng để đối chiếu. Đây là bằng chứng biên tập, không phải bản clone đầy đủ của từng repo.
- `source/repository-evidence.json`: kết quả kiểm tra các repo cũ, gồm chuyển tên và URL không còn công khai.
- `source/demo-link-checks.json`: kết quả HTTP của demo tại thời điểm kiểm tra.
- `rewritten/*.md`: 11 case study để đọc hoặc xuất riêng.
- `../../src/content/projects.json`: dữ liệu biên tập được website sử dụng.

## Thay đổi có căn cứ

| Dự án                             | Điều chỉnh                                                                                                               |
| --------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| File Uploader                     | Next.js 16 / React 19; API lưu file trong Map của server, không mô tả là Catbox hay lưu bền vững.                        |
| Khanh Nguyen Blog                 | Firestore thay cho mô tả GitHub Issues/GraphQL; dùng repo my-blog và domain blog hiện tại.                               |
| Hue Festival                      | Next.js 14 theo package manifest; gỡ điểm Lighthouse chưa có báo cáo.                                                    |
| Mini PhotoBooth                   | Repo mini-photobooth, URL demo đích sau chuyển hướng; mô tả capture 4 ảnh và PNG theo README.                            |
| SPIT Management                   | Spring Boot / Java 21 thay cho Nest.js; thêm repo công khai đã tìm thấy.                                                 |
| Weather App                       | Dự báo 5 ngày theo README, không quảng bá 7 ngày.                                                                        |
| TodoList                          | Cập nhật repo todolist sau chuyển tên.                                                                                   |
| Next Document Hub và SPIT Express | Giữ phạm vi từ hồ sơ dự án, ghi rõ tình trạng nguồn; không giả định Open Document là repo đổi tên của Next Document Hub. |

Các demo trả 404 không còn là nút truy cập: File Uploader, Next Document Hub, TodoList và Weather App. Không tạo URL demo thay thế bằng cách đoán tên domain.

## Cách tích hợp

Dữ liệu Firestore giữ vai trò xác định các project tồn tại; bản viết lại được ghép theo ID ở cả server và client. Không ghi đè cơ sở dữ liệu production trong lượt làm việc này.

Bản biên tập có ngày cập nhật thật. Nếu chủ website lưu chỉnh sửa mới hơn từ trang quản trị, timestamp mới cho phép dữ liệu đó có ưu tiên. Trang quản trị giữ các phần case study khi lưu. Các file JSON có thể được sửa, review và deploy cùng mã nguồn.

## Xác minh

Đối chiếu hướng dẫn Google tại [ghi chú nghiên cứu SEO](../../../my-blog/docs/seo/editorial-research.md). Chạy `node --test tests/project-content.test.mjs`, lint và build. Kiểm tra nội dung, canonical, liên kết và schema trong HTML build trước khi deploy.
