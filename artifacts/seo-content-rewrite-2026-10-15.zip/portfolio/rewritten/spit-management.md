# SPIT Management — Spring Boot & Next.js

A club-management system with Java Spring Boot, Next.js and MySQL, covering members, semesters, tasks, notifications and role-based access control.

## Modeling club operations across the full stack

SPIT Management is a full-stack club-management system with a Java backend and a Next.js frontend. Its documented workflows cover users, members, boards, semesters, tasks, task requests and internal notifications. That domain is a useful setting for discussing Fullstack engineering because access rules and data relationships affect the UI as well as the API.

A semester is more than a filter label: it provides context for membership records, responsibilities and dashboard statistics. The application needs consistent definitions across those views. Modeling the same workflow across the interface, API and database is the central Fullstack concern in this project.

## Backend and frontend architecture

The public repository identifies Java 21, Spring Boot 3, Spring Security, Spring Data JPA, MySQL and Flyway on the backend. It documents JWT access and refresh tokens, BCrypt password hashing, validation and OpenAPI documentation. Cloudinary supports avatar uploads.

The frontend uses Next.js 16, React 19, TypeScript, Ant Design and TanStack Query. Docker Compose brings the frontend, Spring Boot backend and MySQL database together for local setup. Flyway tracks database changes, while OpenAPI documentation provides a reference for the API boundary.

## Why this is a useful Fullstack case study

This project lets a reviewer follow a business workflow through the interface, API authorization and relational persistence. The code and setup instructions provide a concrete starting point for discussing model boundaries, database migration and client query state. The smaller Express and Flask projects provide useful comparisons for how similar concerns appear in different stacks.

## Related work and evidence

Review the architecture, setup instructions and documented workflows. [SPIT Management public repository](https://github.com/knguyen1411b/spit-management).

Inspect the backend framework and persistence libraries. [Spring Boot backend dependencies](https://github.com/knguyen1411b/spit-management/blob/main/backend/build.gradle).

Compare the club-management domain in another backend stack. [Earlier Express API case study](https://ndknguyen.io.vn/projects/spit-express).

Read my checklist for reviewing changes across UI, API and data boundaries. [AI-assisted Fullstack development workflow](https://blog.ndknguyen.io.vn/ky-nguyen-ai-pair-programming-tro-ly-antigravity-co-the-lam-duoc-gi-cho-du-an-cua-ban).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
