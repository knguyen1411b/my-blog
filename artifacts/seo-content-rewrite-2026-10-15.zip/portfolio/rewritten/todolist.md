# TodoList — Flask & SQLAlchemy Task App

A Flask task-management application with user sign-in, notes CRUD, completion tracking and profile statistics, using SQLAlchemy, SQLite and Jinja templates.

## A small application with a complete user workflow

TodoList is a Python Flask application that connects authentication to a practical task-management workflow. Users sign in, create notes, revise or remove them, and mark work complete. A profile dashboard summarizes total, completed and pending notes, making the task state understandable beyond an individual checkbox.

The scope is deliberately compact. A small task application is useful portfolio evidence when it shows the relationship between identity, data ownership, persistence and UI feedback. Those responsibilities are easier to inspect here than in a larger application with many unrelated features.

## Server-rendered interface and JSON endpoints

The public README describes Flask-Login, Flask-SQLAlchemy and SQLite, with Jinja2 templates and Tailwind CSS delivered through a CDN. Route blueprints, services, templates and models are organized separately. A small JSON API supports listing notes and other note-management operations.

SQLite keeps local setup simple. The repository documents environment configuration and a pytest suite, with GitHub Actions running tests across multiple Python versions. Source code and setup instructions provide a direct way to review the routes and run the application locally.

## A comparison point for Fullstack interviews

This project provides a useful contrast to a React dashboard backed by a separate Java API. Server-rendered forms can solve a focused workflow with fewer client-side moving parts, while a larger management system has different interaction and integration needs. Comparing these approaches makes the choice of stack a concrete engineering discussion.

## Related work and evidence

Review the documented routes, architecture and tests. [TodoList Flask repository and setup](https://github.com/knguyen1411b/todolist).

Compare this focused Python application with a Java and React system. [SPIT Management full-stack dashboard](https://ndknguyen.io.vn/projects/spit-management).

Explore another approach to authenticated backend operations. [Express and MySQL API case study](https://ndknguyen.io.vn/projects/spit-express).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
