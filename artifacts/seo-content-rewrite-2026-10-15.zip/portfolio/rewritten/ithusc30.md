# IT HUSC 30 — University Anniversary Website

A Next.js and TypeScript anniversary landing page for IT HUSC, with animated timelines, section navigation and responsive layouts for an institutional story.

## Organizing an anniversary story

IT HUSC 30 is a commemorative landing-page project centered on the 30th anniversary of the Faculty of Information Technology at the University of Sciences, Hue University. The page brings a timeline and event-oriented sections into one navigable experience.

An anniversary page has a different reading pattern from a utility application. Visitors may arrive for background, a historical milestone or event information. The interface therefore needs recognizable sections and a clear path between them, while allowing imagery and motion to communicate the occasion.

## Implementation choices

The repository describes a Next.js 14 and TypeScript application with React, Tailwind CSS, NextUI, Sass, Framer Motion and AOS. React Scroll and a vertical timeline component support the section-based journey and historical presentation.

The documented project structure separates route entry points, page sections, reusable components, styles and configuration data. That organization is useful for a campaign page where content and visual presentation need to evolve together. It avoids treating the entire experience as one large, hard-to-review component.

## What to inspect

The public demo is the place to review section navigation and responsive behavior. The code provides the implementation context. Hue Festival is a complementary case study with a more geographic focus: its content journey includes map-based exploration, whereas this project centers on an anniversary narrative and timeline.

## Related work and evidence

Explore the timeline and section navigation. [View the IT HUSC anniversary website](https://ithusc30.vercel.app/).

Review the layout structure and documented technology choices. [IT HUSC 30 repository](https://github.com/knguyen1411b/ithusc30).

Compare another narrative website with interactive map content. [Hue Festival cultural landing page](https://ndknguyen.io.vn/projects/huefestival).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
