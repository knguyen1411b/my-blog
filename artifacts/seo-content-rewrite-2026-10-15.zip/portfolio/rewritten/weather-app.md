# Weather App — Next.js Forecast Dashboard

A Next.js weather dashboard with city search, current conditions, charts, maps and a five-day forecast, using React, TypeScript and OpenWeatherMap data.

## Making weather data understandable

Weather App presents several kinds of weather information in one interface: current conditions, forecast data, charts and a geographic view. Its user task starts with choosing a city and continues with understanding what the response means for that place. The design problem is therefore both an API-integration problem and an information-presentation problem.

The weather dashboard brings current temperature, wind, visibility, sunrise, UV and air-quality information into a city-based view. Hourly temperature presentation and a five-day forecast provide different time horizons, helping users distinguish present conditions from upcoming changes.

## Rendering and visualization

The repository uses Next.js 14, React 18 and TypeScript. Recharts supports chart-based presentation; Leaflet and React Leaflet support the map; next-themes provides theme controls. Tailwind CSS and UI components organize the dashboard.

The README describes server-side loading of weather data before rendering the initial page. That is a useful contrast with purely client-fetched widgets: the initial response can contain meaningful content, while subsequent interactions still need clear loading and error behavior. Displaying weather units and forecast periods consistently is part of making API data understandable.

## What to review in the source

This case study provides a focused discussion of external-data integration and UI composition. The public repository includes the documented feature set and setup context. Hue Festival offers a related geographic interface, using a map to help visitors explore cultural landmarks.

## Related work and evidence

Review the documented dashboard features and frontend stack. [Weather App repository](https://github.com/knguyen1411b/weather-app).

Compare map-based context in a different user journey. [Hue Festival interactive landmark map](https://ndknguyen.io.vn/projects/huefestival).

Explore another application where initial server-rendered content matters. [Next.js publishing application](https://ndknguyen.io.vn/projects/my-blog).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
