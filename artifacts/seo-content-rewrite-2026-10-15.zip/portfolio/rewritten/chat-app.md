# Chat App — Next.js & Firebase Messaging

A room-based chat application by Khanh Nguyen, built with Next.js, React and Firebase for authentication, member management and real-time messaging.

## Messaging starts with users and rooms

Chat App connects authentication, room membership and conversations in a single web interface. A user signs in, creates a room, adds participants and exchanges messages. Room membership gives the application a concrete domain model: people communicate within an identified conversation instead of an unstructured global feed.

Signing in, opening a room and updating its member list all affect what the user can see and do. The interface brings these states together so a conversation remains connected to its participants. This makes the project a focused example of how shared application data becomes an interactive React experience.

## Implementation and interaction flow

The repository uses Next.js 14, React 18, Firebase, TypeScript, Material UI and Tailwind CSS. Its README describes Google, Facebook and email/password authentication, creating rooms, adding members by selection or user ID, and managing rooms and participants. These are the main behaviors to inspect in the source.

Separating sign-in forms, room controls and the conversation interface makes the code easier to navigate. Real-time updates also require attention to listener cleanup and loading states. Those concerns are review criteria for a messaging application, not a claim that its authentication alone proves every room permission is secure.

## What this project demonstrates

For a Fullstack role, this project provides a focused discussion of identity, shared data and interactive UI state. It complements the server-rendered publishing flow in Khanh Nguyen Blog: both use Firebase, while a chat room has very different update and membership requirements from a published article.

## Related work and evidence

Review the implementation and screenshots in the public repository. [Chat App source code and setup instructions](https://github.com/knguyen1411b/chat-app).

Compare the messaging flow with a content publishing application. [Next.js blog with Firestore and Markdown](https://ndknguyen.io.vn/projects/my-blog).

Read how I frame small changes and verify application behavior. [AI pair programming: a verification-first workflow](https://blog.ndknguyen.io.vn/ky-nguyen-ai-pair-programming-tro-ly-antigravity-co-the-lam-duoc-gi-cho-du-an-cua-ban).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
