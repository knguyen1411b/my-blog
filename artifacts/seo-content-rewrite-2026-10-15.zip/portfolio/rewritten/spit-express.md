# SPIT API — Express & MySQL Backend

An Express and MySQL backend case study for club administration, covering authentication, role-based access and relational data access with Sequelize.

## A backend for club administration

SPIT API is an earlier backend project focused on club-management operations. It combines Node.js, Express, MySQL, Sequelize and JWT to connect incoming requests with identity, authorization and relational data.

A management API needs to distinguish a signed-in user from a user allowed to perform a particular action. Authentication establishes identity; authorization checks access to a resource or operation. Keeping those responsibilities separate makes the backend easier to reason about and discuss during a technical interview.

## API and data responsibilities

Role-based middleware handles access decisions, while Sequelize provides the data-access layer for MySQL records. Express provides the request-routing layer. This separation gives the application distinct places for request handling, business behavior and persistence.

This is an archived backend case study; a public source repository and live API are currently unavailable. The related SPIT Management implementation has public source code for reviewing club workflows, backend dependencies and setup instructions.

## Related implementation to review

The publicly available SPIT Management System is a separate implementation using Spring Boot and Next.js. It offers inspectable examples of club workflows and documented authorization boundaries. Comparing the two entries is useful for discussing how the same business concerns can be expressed in different backend stacks without treating them as interchangeable codebases.

## Related work and evidence

Review a related club-management implementation with a public repository. [SPIT Management — Spring Boot and Next.js case study](https://ndknguyen.io.vn/projects/spit-management).

Compare another application built around authenticated CRUD operations. [Flask task-management application](https://ndknguyen.io.vn/projects/todolist).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
