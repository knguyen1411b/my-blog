# Next Document Hub — Document Browsing & Preview

A document browsing project using Next.js and TypeScript, focused on finding shared resources, navigating categories and previewing documents in the browser.

## Finding a document is part of the product

Next Document Hub is a Next.js and TypeScript project for browsing shared resources, searching by context and previewing documents in the browser. Its central workflow runs from finding a relevant topic to opening an actual resource. Navigation and preview work together to help users decide which document to read.

Categories give users a route when they do not know the exact document name. Search supports a more direct lookup. Preview helps them decide whether a result is useful before leaving the browsing experience. These are complementary ways to reduce friction in a document collection.

## Application scope and integration boundaries

The project combines a Next.js interface, TypeScript, the Google Drive API and Tailwind CSS. Document discovery and document viewing are distinct responsibilities: categories and search help locate a resource, while the preview workflow presents its contents. External document access is also a separate concern from page layout.

This case study is retained as an archived project. Its previous public demo and source repository are currently unavailable. For an inspectable example of related work, the links below include Open Document, a separate application for document-tree navigation.

## Document workflows in context

Document browsing connects naturally to my article on PDF translation: finding the right file and understanding its contents are consecutive parts of the same task. File Uploader covers a different boundary, where files enter an application through an upload API. These related examples make the portfolio useful as a set of engineering discussions rather than isolated screenshots.

## Related work and evidence

Read about evaluating a PDF translation workflow after finding a document. [PDF translation while preserving document layout](https://blog.ndknguyen.io.vn/cong-cu-dich-pdf-giu-nguyen-cong-thuc-hinh-anh-va-bo-cuc-pdf-translate).

Compare document browsing with a file-upload application. [File Uploader: server storage and QR sharing](https://ndknguyen.io.vn/projects/file-uploader).

Explore related public work on document-tree navigation. [Open Document — a separate public document browser](https://github.com/knguyen1411b/open-document).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
