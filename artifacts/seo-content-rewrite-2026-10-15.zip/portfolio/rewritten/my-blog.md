# Khanh Nguyen Blog — Next.js & Firestore

A technical blog by Khanh Nguyen built with Next.js, React, TypeScript and Firestore, featuring Markdown publishing, an admin editor and article metadata.

## A publishing system connected to my portfolio

Khanh Nguyen Blog is the publishing side of my developer portfolio. It presents technical articles about tools, web development and engineering workflows, with an author profile linking back to my projects and CV. The goal is to make technical reasoning readable as well as make the implementation inspectable.

The application connects a public reading experience with a separate administration workflow. Firestore supplies the content, Markdown keeps technical writing editable, and route-level metadata describes each published article. The same author identity connects the blog to the portfolio.

## Content, rendering and discovery

Next.js 16 and React 19 provide the route structure and UI. Firestore stores articles; TanStack Query supports the client data layer. React Markdown, Remark GFM and Rehype plugins render article content, code and headings. The reading interface includes search, category filters, a table of contents and author information.

The SEO work keeps a canonical URL for each article, generates social metadata and describes articles with structured data. Published content is included in the sitemap and RSS feed. An authenticated editor supports draft and published states, keeping content management separate from the public reading flow.

## Connecting technical writing to practical work

A blog is useful evidence when its explanations connect to code rather than repeat a technology list. The AI pair programming article discusses verification and review; the PDF translation article explores a document workflow. Readers can move from those explanations to related project case studies and then to my CV if they want the broader context.

## Related work and evidence

Browse the published technical articles. [Read Khanh Nguyen Blog](https://blog.ndknguyen.io.vn).

Inspect the Firestore service, Markdown renderer and route metadata. [Current blog source code](https://github.com/knguyen1411b/my-blog).

Read the engineering workflow article. [AI pair programming with review and verification](https://blog.ndknguyen.io.vn/ky-nguyen-ai-pair-programming-tro-ly-antigravity-co-the-lam-duoc-gi-cho-du-an-cua-ban).

Read a practical tool-selection article. [PDF translation and document layout](https://blog.ndknguyen.io.vn/cong-cu-dich-pdf-giu-nguyen-cong-thuc-hinh-anh-va-bo-cuc-pdf-translate).

Compare a publishing flow with a room-based messaging flow. [Firebase messaging application](https://ndknguyen.io.vn/projects/chat-app).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
