# Hue Festival — Next.js Cultural Landing Page

A responsive Hue Festival landing page using Next.js, React, animation and interactive maps to present performances, cuisine, craft villages and landmarks.

## Turning a cultural theme into a usable page

Hue Festival is a landing-page project that brings together performances, local food, traditional crafts and places to visit. Its central design problem is information hierarchy: a visitor should be able to understand the event theme and find a relevant section without working through an unstructured gallery.

The page treats visual storytelling and navigation as related concerns. Images establish context, while section organization gives visitors a clear browsing path through the cultural showcase. Arts, cuisine, crafts and landmarks each have a distinct place in that journey.

## Interface architecture and mapping

The public package manifest identifies Next.js 14 and React 18, together with TypeScript, Tailwind CSS, Framer Motion, AOS and Lenis. Leaflet and React Leaflet support the landmark map. The README documents sections for arts, cuisine, craft villages and Hue landmarks.

Combining a long page with scroll effects requires care: animations should support reading rather than hide essential information, and a map should supplement useful text rather than become the only route to a location. These are the interaction tradeoffs the project makes available for review.

## Reviewing the work

The live demo shows the visual direction, and the repository makes the chosen libraries and organization inspectable. The IT HUSC anniversary website explores another content-heavy landing page. Together, these projects show two approaches to presenting a narrative through reusable frontend sections.

## Related work and evidence

View the page structure, visual sections and interactive map. [Explore the Hue Festival landing page](https://huefestival.vercel.app/).

Inspect the implementation and dependency manifest. [Hue Festival source code](https://github.com/knguyen1411b/huefestival).

See a related approach to timelines and section navigation. [IT HUSC anniversary landing page](https://ndknguyen.io.vn/projects/ithusc30).

For my broader skills and background, view my CV. [Khanh Nguyen — Fullstack Software Engineer CV](https://ndknguyen.io.vn/cv).
