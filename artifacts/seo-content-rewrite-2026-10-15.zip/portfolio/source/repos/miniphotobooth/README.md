# Mini Photo Booth

A lightweight web photobooth built with Next.js that lets users capture a 4-shot strip quickly, choose a frame color, and export to PNG.

![Demo](app/image.png)

## Features

- Camera-first capture flow
- Manual or auto capture mode
- Countdown select before each shot
- 4-photo strip preview
- Rounded-corner PNG export
- Mobile-friendly responsive UI

## Tech Stack

- Next.js 16
- React 19
- TypeScript
- Tailwind CSS v4
- HeroUI

## Getting Started

### Prerequisites

- Node.js 20+
- pnpm 9+

### Install

```bash
pnpm install
```

### Run in development

```bash
pnpm dev
```

Open `http://localhost:3000`.

### Build

```bash
pnpm build
pnpm start
```

## Project Structure

```text
app/
  page.tsx                  # landing page
  capture/
    page.tsx                # capture route entry
    _components/            # capture UI
    _hooks/                 # capture logic hooks
    _lib/                   # workflow/state reducer
    _constants/             # presets and constants
    _types/                 # shared capture types
```

## Scripts

- `pnpm dev`: start dev server
- `pnpm build`: production build
- `pnpm start`: run production server
- `pnpm lint`: lint project
- `pnpm format`: format with Prettier

## Notes

> [!TIP]
> Use HTTPS or localhost and allow camera permission in your browser for full functionality.
